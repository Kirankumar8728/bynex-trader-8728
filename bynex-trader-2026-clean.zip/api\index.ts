// ============================================================================
// Vercel Serverless API Handler
// Self-contained — does NOT import the full server.ts to avoid pulling in
// Telegram, Firebase Admin, Vite, archiver, Google GenAI, etc.
// ============================================================================
import type { VercelRequest, VercelResponse } from '@vercel/node';

const OAUTH_CLIENT_ID = process.env.VITE_DERIV_CLIENT_ID || process.env.DERIV_CLIENT_ID || '32FjINZV8sXfdKQcVvnZf';

export default async function handler(req: VercelRequest, res: VercelResponse) {
  // Enable CORS for same-origin and Vercel preview deployments
  res.setHeader('Access-Control-Allow-Origin', req.headers.origin || '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  const path = req.url?.replace(/\?.*$/, '') || '';

  // ── Health check ──────────────────────────────────────────────────────
  if (path === '/api/health') {
    return res.status(200).json({ status: 'ok', serverless: true });
  }

  // ── Token exchange ────────────────────────────────────────────────────
  if (path === '/api/deriv/token' && req.method === 'POST') {
    const { code, code_verifier, redirect_uri } = req.body || {};

    if (!code || !code_verifier || !redirect_uri) {
      console.error('[AUTH ERROR] Missing required parameters', {
        hasCode: !!code,
        hasVerifier: !!code_verifier,
        hasRedirect: !!redirect_uri
      });
      return res.status(400).json({
        error: 'Missing required parameters (code, code_verifier, or redirect_uri)'
      });
    }

    console.log(`[AUTH] Token exchange — code: ${code.substring(0, 8)}… client: ${OAUTH_CLIENT_ID} redirect: ${redirect_uri}`);

    try {
      const tokenParams = new URLSearchParams({
        grant_type: 'authorization_code',
        code,
        client_id: OAUTH_CLIENT_ID,
        redirect_uri,
        code_verifier,
      });

      const derivRes = await fetch('https://auth.deriv.com/oauth2/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: tokenParams.toString(),
      });

      const data = await derivRes.json();

      if (!derivRes.ok) {
        console.error('[AUTH ERROR] Deriv rejected token exchange:', {
          status: derivRes.status,
          error: data.error,
          description: data.error_description,
          hint: data.error_hint,
        });
        return res.status(derivRes.status).json({
          error: data.error_description || data.error || 'Token exchange failed',
          deriv_error: data.error,
          details: data,
        });
      }

      console.log('[AUTH SUCCESS] Token exchange completed');
      return res.status(200).json({
        access_token: data.access_token,
        expires_in: data.expires_in,
        token_type: data.token_type,
      });
    } catch (err: any) {
      console.error('[AUTH CRITICAL] Exception during token exchange:', err);
      return res.status(500).json({
        error: 'Internal server error during authentication',
        message: err.message,
      });
    }
  }

  // ── Session (stateless on Vercel — always returns 401) ────────────────
  if (path === '/api/deriv/session') {
    return res.status(401).json({ error: 'No active session (serverless)' });
  }

  // ── Logout (no-op on Vercel serverless) ───────────────────────────────
  if (path === '/api/deriv/logout' && req.method === 'POST') {
    return res.status(200).json({ success: true });
  }

  // ── 404 for unknown API routes ────────────────────────────────────────
  return res.status(404).json({ error: 'API route not found', path });
}
